const {nanoid} =require('nanoid') ;
exports.nanoid = ()=>{
    return nanoid();
}