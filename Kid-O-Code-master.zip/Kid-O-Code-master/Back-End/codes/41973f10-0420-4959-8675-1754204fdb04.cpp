# Enter your code here
#include<iostream>
using namespace std;
int main()
{
    cout<<"sdfg";
}