const htmlValues = ["python", "excel", "web", "js", "data", "aws", "draw"];
export default htmlValues;