const links = [
    [
        {
            text: 'About us',
            href: 'about'
        },
        {
            text: 'Get the app',
            href: 'about'
        },
        {
            text: 'Contact us',
            href: 'about'
        }
    ],
    [
        {
            text: 'Careers',
            href: 'about'
        },
        {
            text: 'Blog',
            href: 'about'
        },
        {
            text: 'Help and Support',
            href: 'about'
        }
    ],
    [
        {
            text: 'Terms',
            href: 'about'
        },
        {
            text: 'Privacy policy',
            href: 'about'
        },
        {
            text: 'Cookie settings',
            href: 'about'
        }
    ]
];

export default links;