export const userData = {
    name: "John Doe",
    userID : "1234",
    email: "john.doe@example.com",
    joinedDate: "January 1, 2022",
    progress: 6, // Progress percentage
  };
  
  export const quizData = [
    { name: "Quiz", score: 8, totalMarks: 10, attempted: true },
  ];